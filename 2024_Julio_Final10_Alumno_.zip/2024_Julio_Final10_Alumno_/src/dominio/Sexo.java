package dominio;

public enum Sexo {
	
}
