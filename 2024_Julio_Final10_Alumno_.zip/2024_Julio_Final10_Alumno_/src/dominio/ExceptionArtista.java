package dominio;

@SuppressWarnings("serial")
public class ExceptionArtista extends Exception{
	
}
