package dominio;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Comparator;
import java.util.GregorianCalendar;

public class Artista {
	
	private String nombre;
	private GregorianCalendar fechaNacto;
	private Sexo sexo;
	
	public Artista(String nombre, GregorianCalendar fechaNacto, Sexo sexo) throws ExceptionArtista {
		
	}
	
	public String getFechaCorta() {
		 
	}
	
	public int getEdad() {
		
	}
		
}

