package dominio;

import java.util.ArrayList;
import java.util.Collections;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class GestorArtista {
	
	private static GestorArtista ga;
	private ArrayList<Artista> misArtistas;
	
	private GestorArtista() {
		
	}
	
	public static GestorArtista getInstancia() {
		
	}
	
	public boolean addArtista(Artista a) {
		
	}

	public int cantidadDeArtistas() {
	
	}

	public void blanquearArtistas() {
		
	}

	public ArrayList<Artista> getArtistas(String parteNombre) {
		
	}
	
	public ArrayList<Artista> getArtistasImplementarConLambda(String parteNombre) {
		
	}
	
	public ArrayList<Artista> getArtistasImplementarConLambda(int edadLimiteSuperior) {
		
	}
	
	public ArrayList<Artista> getArtistas(int edadLimiteSuperior) {
		
	}
	
	public ArrayList<Artista> getArtistas() {
		
	}
	
	public String getPromedioEdadArtistas(){
		
	}
	
	public String getPromedioEdadArtistas(Sexo s){
		
	}
	
}
